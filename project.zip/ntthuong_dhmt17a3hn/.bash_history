# 1. Tự động lấy đúng Project ID và bật Compute Engine API
gcloud config set project $(gcloud projects list --format='value(projectId)' | head -n1)
gcloud services enable compute.googleapis.com
# 2. Thiết lập Region & Zone chuẩn
gcloud config set compute/region us-central1
gcloud config set compute/zone us-central1-a
# 3. Tạo VM web-server-base và Mở Firewall
gcloud compute instances create web-server-base   --zone=us-central1-a   --machine-type=e2-medium   --tags=http-server   --metadata=startup-script='#!/bin/bash
apt-get update
apt-get install -y apache2 stress
cat <<EOF > /var/www/html/index.html
<h2>Google Cloud Compute Engine Web Server</h2>
<p>Instance Name: $(hostname)</p>
EOF'
gcloud compute firewall-rules create allow-http-80   --allow=tcp:80   --target-tags=http-server
# 4. Tắt VM gốc & Tạo Custom Image
gcloud compute instances stop web-server-base --zone=us-central1-a
gcloud compute images create my-custom-web-image   --source-disk=web-server-base   --source-disk-zone=us-central1-a   --family=my-web-family
# 5. Tạo Instance Template & MIG kèm Auto Scaling
gcloud compute instance-templates create my-web-template   --machine-type=e2-medium   --image=my-custom-web-image   --tags=http-server
gcloud compute instance-groups managed create my-auto-mig   --zone=us-central1-a   --template=my-web-template   --size=1
gcloud compute instance-groups managed set-autoscaling my-auto-mig   --zone=us-central1-a   --min-num-replicas=1   --max-num-replicas=4   --target-cpu-utilization=0.50   --cool-down-period=60
# 6. Sinh tải CPU để test Auto Scaling
VM_MIG_NAME=$(gcloud compute instance-groups managed list-instances my-auto-mig --zone=us-central1-a --format='get(instance)' | head -n1)
gcloud compute ssh $VM_MIG_NAME --zone=us-central1-a --command='sudo stress --cpu 2 --timeout 300s &'
gcloud config set compute/region us-central1
gcloud config set compute/zone us-central1-a
gcloud config list
gcloud compute instances create web-server-base   --zone=us-central1-a   --machine-type=e2-medium   --tags=http-server   --metadata=startup-script='#!/bin/bash
apt-get update
apt-get install -y apache2 stress
cat <<EOF > /var/www/html/index.html
<h2>Google Cloud Compute Engine Web Server</h2>
<p>Instance Name: $(hostname)</p>
EOF'
gcloud compute firewall-rules create allow-http-80   --allow=tcp:80   --target-tags=http-server
# Lấy địa chỉ IP và kiểm tra kết quả:
gcloud compute instances list
curl http://$(gcloud compute instances describe web-server-base --zone=us-central1-a --format='get(networkInterfaces[0].accessConfigs[0].natIP)')
gcloud compute instances stop web-server-base --zone=us-central1-a
gcloud compute images create my-custom-web-image   --source-disk=web-server-base   --source-disk-zone=us-central1-a   --family=my-web-family
# Kiểm tra Image đã tạo:
gcloud compute images list --filter='name~my-custom-web-image'
gcloud compute instance-templates create my-web-template   --machine-type=e2-medium   --image=my-custom-web-image   --tags=http-server
gcloud compute instance-groups managed create my-auto-mig   --zone=us-central1-a   --template=my-web-template   --size=1
gcloud compute instance-groups managed set-autoscaling my-auto-mig   --zone=us-central1-a   --min-num-replicas=1   --max-num-replicas=4   --target-cpu-utilization=0.50   --cool-down-period=60
VM_MIG_NAME=$(gcloud compute instance-groups managed list-instances my-auto-mig --zone=us-central1-a --format='get(instance)' | head -n1)
gcloud compute ssh $VM_MIG_NAME --zone=us-central1-a --command='sudo stress --cpu 2 --timeout 300s &'
gcloud compute instance-groups managed list-instances my-auto-mig --zone=us-central1-a
